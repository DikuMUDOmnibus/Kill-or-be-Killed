DECLARE_SPELL_FUN(	spell_flight	);
DECLARE_SPELL_FUN(      spell_dew    );
DECLARE_SPELL_FUN(      spell_titans    );
DECLARE_SPELL_FUN(      spell_guarding    );
DECLARE_SPELL_FUN(      spell_balmy_sleep    );
DECLARE_SPELL_FUN(      spell_storms    );
DECLARE_SPELL_FUN(      spell_deafening_pitch    );
DECLARE_SPELL_FUN(      spell_healing    );
DECLARE_SPELL_FUN(	spell_insanity   );
DECLARE_SPELL_FUN(	spell_chilliness_of_death    );
DECLARE_SPELL_FUN(	spell_resting	);
DECLARE_SPELL_FUN(	spell_armageddon	);
DECLARE_SPELL_FUN(	spell_hour_of_rising	);
DECLARE_SPELL_FUN(	spell_stonelike_resolve	);
DECLARE_SPELL_FUN(	spell_divine_blessing ); //Bless for bards -- Ceial
DECLARE_SPELL_FUN(	spell_phantom	);

